#include <getopt.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <math.h>
#include <limits.h>
#include <string.h>

#include "cachelab.h"

/* cache struct define here */
typedef struct cache_line{
    char valid;
    unsigned long long tag;
    unsigned long long count;
}cache_line;

/* global paramater define here */
// command line paramaters
unsigned int s = 0, E = 0, b = 0, v = 0;
// cache file address 
char* t = NULL;
// counters 
int miss_count = 0, hit_count = 0, eviction_count = 0;
// num of index and address
unsigned group_num = 0;
unsigned addr_num = 0;
// cache
cache_line** cache = NULL;
// addr mask
unsigned long long mask = 0;

/* function declear here */
void printHelp(char* source);
void initCache(void);
void dropCache(void);
void runCache(char* t);
void accessCache(unsigned long long addr);

/* start here */
int main(int argc,char* argv[]){
    char ch;
    /* get paramaters from command line */
    while((ch = getopt(argc, argv, "s:E:b:t:hv")) != -1){
	switch(ch){
	case 's' :
	    s = atoi(optarg);
	    group_num = (unsigned int)pow(2, s);//caculate cache groups number
			break;
		case 'E' :
			E = atoi(optarg);
			break;
		case 'b' :
			b = atoi(optarg);
			addr_num = (unsigned int)pow(2, b);
			break;
		case 't' :
			t = optarg;
			break;
		case 'h' :
			printHelp(argv[0]);
			exit(0);
			break;
		case 'v' :
			v = 1;
			break;
		default :
			printHelp(argv[0]);
			exit(-1);
		}
	}
    /* check paramater */
    if(s ==0 || E == 0 || b == 0 || t == NULL){
		printHelp(argv[0]);
        exit(-1);
    }
    initCache();
    runCache(t);
    dropCache();
    printSummary(hit_count, miss_count, eviction_count);
    return 0;
}

void printHelp(char* source){
    printf("Usage: %s [-hv] -s <num> -E <num> -b <num> -t <file>\n", source);
    printf("Options:\n");
    printf("  -h         Print this help message.\n");
    printf("  -v         Optional verbose flag.\n");
    printf("  -s <num>   Number of set index bits.\n");
    printf("  -E <num>   Number of lines per set.\n");
    printf("  -b <num>   Number of block offset bits.\n");
    printf("  -t <file>  Trace file.\n");
    printf("\nExamples:\n");
    printf("  linux>  %s -s 4 -E 1 -b 4 -t traces/yi.trace\n", source);
    printf("  linux>  %s -v -s 8 -E 2 -b 4 -t traces/yi.trace\n", source);
    exit(0);
}

void initCache(void){
    int i,j;
	//create cache buf as 2d array,each line as a group
    cache = (cache_line**)malloc(sizeof(cache_line*) * group_num);
    if(cache == NULL){
    	exit(-1);
    }
    for(i = 0; i < group_num; i++){
    	cache[i] = (cache_line*)malloc(sizeof(cache_line) * E);
    	if(cache[i] == NULL){
    		exit(-1);
    	}
		//initial cache slot
    	for(j = 0; j < E; j++){
    		cache[i][j].valid = 0;
    		cache[i][j].tag = 0;
    		cache[i][j].count = 0;
    	}
    }
    mask = group_num - 1;//caculate the mask of index 
}
void dropCache(void){
	int i;
	for(i = 0; i < group_num; i++){
		free(cache[i]);
	}
	free(cache);
}
void runCache(char* t){
	unsigned long long addr;
	unsigned int size;
	char op[1];
	FILE* fp = NULL;
	if((fp = fopen(t, "r")) == NULL){
		printf("open trace file error.\n");
		exit(-1);
	}
	while(fscanf(fp, " %c %llx,%d", op, &addr, &size) > 0){
		if(v == 1 && op[0] !='I'){
			printf("%c %llx,%d ", op[0], addr, size);
		}
		switch(op[0]){
		case 'L' :
		case 'S' :
			accessCache(addr);
			break;
		case 'M' :
			accessCache(addr);
			accessCache(addr);
			break;
		default :
			break;
		}
		if(v == 1 && op[0] != 'I'){
			putchar('\n');
		}
	}
	fclose(fp);
}
void accessCache(unsigned long long addr){
	int i;
	unsigned long long set_index = (addr >> b) & mask;
	unsigned long long tag = addr >> (s + b);
	cache_line* cache_group = cache[set_index];
	for(i = 0; i < E; i++){
		if(cache_group[i].valid) cache_group[i].count++;
	}
	// hit
	for(i = 0; i < E; i++){	
		if(cache_group[i].valid && cache_group[i].tag == tag){
			if(v == 1) printf("hit ");
			hit_count++;
			cache_group[i].count = 0;
			return;
		}
	}
	if(v == 1) printf("miss ");
	// miss
	miss_count++;
	// replace
	unsigned long long max_count = 0;
	int max_index = 0;
	for(i = 0; i < E && cache_group[i].valid; i++){
		if(cache_group[i].count >= max_count){
			max_count = cache_group[i].count;
			max_index = i;
		}
	}
	/* i=E : cache is full,need to replace the longest not used cache slot 
	 * i<E : cache is not full,load in
	*/
	if(i == E){
		if(v == 1) printf("eviction ");
		eviction_count++;
		cache_group[max_index].tag = tag;
		cache_group[max_index].count = 0;
		cache_group[max_index].valid = 1;
	}
	else{
		cache_group[i].tag = tag;
		cache_group[i].count = 0;
		cache_group[i].valid = 1;
	}
}
















